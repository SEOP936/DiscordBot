#!/bin/bash
echo "Starting"
node ./index.js
